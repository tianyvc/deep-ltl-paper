# 网站终稿原始快照

用户指定以下两个目录为当前 Overleaf 网站版本。本轮保留目录名、文件集合与全部文件字节，不在其中写入编译产物。

| 目录 | 版本 | 定位 |
|---|---|---|
| [TLT/](TLT/) | 长版，IEEE journal 排版 | 完整说明、三段算法伪代码与扩展讨论 |
| [TLT__Copy_/](TLT__Copy_/) | 短版，IEEE conference 排版 | 压缩说明，保留实验表，补充若干符号与配置澄清 |

每份入口都是 `manuscript.tex`，各自携带 `ref.bib` 和图像，保持独立可上传。两份同名资源文件完全相同，只有 `manuscript.tex` 不同；为保护网站快照，不对目录内部去重或建立链接。

[论文统一导航](../paper/README.md) · [长短版差异](../paper/review/FINAL_VERSION_COMPARISON.md) · [论文与实现对齐](../paper/review/PAPER_IMPLEMENTATION_ALIGNMENT.md) · [保护哈希与验证](../paper/review/VALIDATION.md)

原样完整编译存在 natbib 引用模式问题。隔离副本改用数字引用后可编译，长版 13 页、短版 9 页；不表示原目录已被修复。详细命令和边界见验证报告。

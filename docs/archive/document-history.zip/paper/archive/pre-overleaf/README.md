# Overleaf 终稿导入前的旧稿

本目录保存此前 `paper/` 根目录的 `paper.tex`、`paper-new.tex`、`references.bib`，三个文件均按原字节迁移，没有改写论文或资源路径。

- `paper.tex`：ICML 风格旧长稿，有独立历史内容，不等同于网站长版。
- `paper-new.tex`：旧 IEEE conference 稿，与网站短版正文相同；差别是 `graphicspath`、融合图文件名和 bibliography 入口。保留它用于追溯此前使用的图片资源，停止作为“当前终稿”入口。
- `references.bib`：旧稿文献库，与终稿 `ref.bib` 的差异主要是 `//rr` 和空行；未在线核验条目真实性。

旧稿仍写有 `figures/` 和 `references` 相对路径，**不能直接从此目录编译**。若需历史复现，应在 `.maintenance/` 建立隔离目录，复制所需旧 `.tex`、本目录的 `references.bib` 及 `../../figures/` 为该目录下的 `figures/`，然后在隔离目录编译。这既保留旧稿原文，也避免编译产物污染档案。旧 ICML 稿还缺 `icml2025.sty`；旧图资源问题详见此前历史验证记录，不据此判断新 Overleaf 终稿。

当前网站终稿见 [统一导航](../../README.md)，本轮迁移清单见 [integration-manifest.json](../../review/integration-manifest.json)。

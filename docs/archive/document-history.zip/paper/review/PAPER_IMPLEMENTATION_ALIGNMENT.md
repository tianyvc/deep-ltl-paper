# 以网站终稿为依据的项目对齐说明

## 1. 文档地位与边界

权威论文快照为 `overleaf/TLT` 与 `overleaf/TLT__Copy_`，共同方法是后续工程对齐的主要依据。短版澄清项与长版独有细节一起作为候选规范；冲突处列为待决策事项，不能擅自任选。本文记录本次静态核对所得，不声称论文已经完整实现，也不更改终稿、训练配置或实验数据。

## 2. 研究目标与共同方法

未知动力学 MDP 与 LDBA 组成乘积过程，策略接收环境状态 s 和逻辑进度 q，目标是提高 LTL 满足表现。有限时间 success rate、折扣奖励、接受状态访问次数分别对应不同统计量，不能混称严格的无限满足概率。

### 2.1 SE-GNN 的论文规格

| 对象 | 共同描述 | 实现前必须确认 |
|---|---|---|
| 图 | 任务 LDBA 的状态和带语义转移 | 不能以公式序列邻接链替代完整自动机 |
| 节点 | 4D：accepting、SCC、initial、normalized distance to F | SCC 定义、不可达和零分母处理 |
| 边 | 6D：fwd/bwd/skip/epsilon 四类 one-hot、target accepting、normalized target distance | 互斥优先级、self-loop/trap、skip 的可实现定义 |
| 网络 | 3 层 GATv2，hidden 64，4 heads，LayerNorm 与残差 | 不只核对配置值，还要核对实际输入和调用 |
| 全图池化 | softmax attention pooling | 权重应在每张图节点集合上归一化 |
| 多尺度短期特征 | 拼接 3 层 pooled embeddings 得 z_short | 保持不同图、batch、rollout 时间轴一致 |
| 当前节点特征 | z_GNN(q) | q 由真实环境转移决定，不能用位置编号替代 |

### 2.2 双价值与融合

- 短期头输入：环境特征、z_short 和当前自动机节点特征；监督为短期 TD 类目标。
- 长期头输入：proximity、自动机历史 LSTM、当前节点特征；论文明确区分其与环境特征的依赖。到达/接受代理与完整回合 MC 的目标定义还需统一。
- 融合：`V_total=(1-β)V_short+βV_long`。短版固定式为 `β=σ(κ*(1-d/d_max-θ))`，给定 `κ=3,θ=.5`；正文 MLP/附录 beta_net 的另一说法暂不视作已裁定规范。
- PPO 使用实际融合 value，并对 short/long 分头计算辅助目标；不能只让独立类返回一个字典就认定训练链路接通。
- 长版补充 short/long hidden 256/128、loss 权重 1.0/.3 等，后续需以明确实验 preset 固化，避免从短版省略推断不存在。

### 2.3 自动机追踪的时序约束

每个并行环境独立保存 q，episode reset 时初始化，在每个真实环境 transition 后用下一状态的命题标签更新。rollout 必须保存对应 q/图元数据，PPO 打乱 minibatch 时只读取历史存储状态，不能在 forward 中再次推进自动机。terminated 与 truncated、epsilon actions、重置以及历史 LSTM 状态须有一致约定。

## 3. 七组实验配置合同

这里根据短版 Opt 列明确组件关系。配置名称表示论文实验设计，**不表示当前 CLI 已完整实现**。

| 配置 | HV | MSGNN | Track | Options |
|---|---|---|---|---|
| baseline | 否 | 否 | 否 | 否 |
| hv_only | 是 | 否 | 否 | 否 |
| msgnn_only | 否 | 是 | 否 | 否 |
| hv_track | 是 | 否 | 是 | 否 |
| msgnn_track | 否 | 是 | 是 | 否 |
| full_no_options | 是 | 是 | 是 | 否 |
| full_all | 是 | 是 | 是 | 是 |

baseline 必须明确是否原始 DeepLTL。原方法的 DeepSets/RNN 序列表示不能被悄悄替换成启用图语义的配置，再继续冠以原基线名称。HV 无 tracking 时如何获取 q/proximity 的合法替代，是上述消融可解释性的一部分，需要实验协议补足。

论文最佳平均配置为 **hv_track (.993)**，不是 full_all (.963)，full_no_options 为 .929，略低于 baseline .933。因此后续目标不是把组件全部打开就宣称最佳，MSGNN 在较小自动机上的额外复杂度与未来更大图价值需分别评估。

## 4. 任务与评估口径

| 项目 | 论文描述 | 需要保留的复现证据 |
|---|---|---|
| 环境 | PointLtl2 / Letter / Flat，有限与无限任务 | 实际 Gym ID、版本、地图、奖励与终止规则 |
| φ1 | F blue ∧ F green；声称 5 states | converter 命令、版本、原图和状态计数 |
| φ2 | F blue ∧ F green ∧ F yellow；声称 12 states | 同上 |
| φ3 | (!blue U green) ∧ F yellow；声称 18 states | 同上，检查 held-out 重叠 |
| 训练 | 约 1M steps，batch64，lr3e-4，Adam，γ_RL .998 | 完整命令、配置快照、预算计数口径 |
| 种子 | 1–5 | 每种子 checkpoint、日志与环境随机性 |
| 评估 | 500 episodes | 每种子还是总计、确定性/采样策略、时间上限 |
| 零样本 | blue/green/yellow 文法组合 | train/validation/test 明确划分、公式去重和同义处理 |
| 区间 | 95% CI | 聚合单位、方法、置信区间与显著性分析脚本 |

百分比统一同时保存原始 SR、百分点差和相对差；跨环境、跨公式和跨种子平均顺序必须固定。有限时域 infinite-task 评估中接受访问指标只能作为代理，不自动等价于无限时域语义满足。

## 5. 当前代码与论文的关键差距

下列证据来自当前源代码静态阅读，定位随未来代码变化而变化，后续修复时应重新核对调用链。

| 优先级 | 论文要求 | 当前观察 | 主要位置 |
|---|---|---|---|
| P0 | rollout 与 PPO 实际使用增强值 | 默认 forward 直接返回基础输出，增强分支需 return_multiscale=True；辅助损失未形成主 PPO 的完整链路 | `src/model/longshort_integration.py:160,179,222` |
| P0 | 合法模型输出接口 | 增强分支对 base_output 使用 `.get('ltl_embedding')`，而基础模型接口为 tuple，存在不匹配 | 同文件 207 |
| P0 | 每个真实 transition 更新 q | tracker.step 放在增强 forward 内，缺少安全的 rollout 时序合同，训练重放可能重复推进 | 同文件 193–198；rollout/采样路径 |
| P0 | 完整 LDBA 图及状态语义 | 当前主图路径主要由序列构造双向邻接链；位置归一化不能代表到 F 的真实距离 | `src/model/model.py` 及图构造/预处理路径 |
| P1 | 长期历史 LSTM 与双头输入 | tracker 主要是 4D 结构特征，没有论文历史 LSTM；short 主要用环境输入、long 用 automaton+formula，维度与合同不同 | `src/model/hierarchical_value.py:26,158` |
| P1 | 明确固定门控或学习门控 | 当前 alpha 来自 weight_net，不等于固定距离 κ/θ 函数 | 同文件 224 |
| P1 | 分头 TD/MC | 当前 compute_loss 使用 v_total 扩成全序列，再交多时间尺度损失，与独立 short/long 监督不同 | integration 255–269 |
| P1 | softmax 图池化和元数据一致 | 主路径池化门控与论文归一化注意力需对齐，切片/反序/minibatch 的图元数据传递需补齐 | model/ltl 图编码、预处理及 PPO batch |
| P1 | 真正原始 baseline | 正式三环境配置已启用 GNN node/edge 特征，关闭 HV 不等于恢复原 DeepLTL | `src/config/model_config.py` |
| P2 | 论文预算可复现 | 现有启动器/训练默认预算、batch 等与论文 1M/batch64 不一致 | `run_*.py` 与 train CLI |
| P2 | 完整七组结果证据 | 现有 CSV 主要为外部/原始基线，缺可追溯七组增强多种子结果 | `results/`、`results_infinite/` |

配置中的 64/3/4、node4/edge6 数值匹配只能证明声明接近，不证明实际图语义、损失或数据流符合论文。

## 6. 建议后续执行顺序

1. **先裁定定义**：距离与 skip、SCC、门控固定/学习、长期目标、HV 无 tracking 的协议、held-out 划分。记录决定及其论文来源，避免先编码再解释。
2. **接通最小 hv_track**：正确 q 时序与状态存储、双价值输出、PPO 实际使用与分头 loss；用真实梯度和 transition 数据验证，而不只检查张量形状。
3. **独立恢复 baseline**：隔离原 DeepLTL 配置与增强配置，固定环境、奖励、预算和评估策略。
4. **补完整图与 MSGNN**：从真实转换器产物构图，补节点/边语义、池化和 batch 元数据；将 Options 单独作为可解释消融。
5. **固化论文 preset 和数据血缘**：七配置×种子，保存 converter 产物、命令、环境、checkpoint、逐回合与训练日志；绘图只消费这些结果。
6. **再判断论文是否需修订**：先解决统计口径和图表冲突，根据真实结果决定，而不以当前稿数字作为必须复现出的目标。

本轮没有执行以上实现任务，也没有更改训练默认参数、结果文件或用户网站终稿。完整差异和数学疑点见 [FINAL_VERSION_COMPARISON.md](FINAL_VERSION_COMPARISON.md)。

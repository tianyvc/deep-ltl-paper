# 论文整合验证记录

## 环境与方法

所有项目脚本和编译由 CloudFolder 路由到远端 `/home/dell/workspace/Tianyvc/deep-ltl-paper`，通过已有 conda 环境 `wty_LTL` 执行；Python 为 `/home/dell/anaconda3/envs/wty_LTL/bin/python`。未安装、升级或降级依赖。

最初 `cf run -- conda run -n wty_LTL ...` 因非交互 PATH 不含 conda 返回 `conda: not found`，已报告。之后显式调用 `/home/dell/anaconda3/bin/conda run -n wty_LTL ...`，没有切换到 base 或本地环境。

```powershell
cf run -- /home/dell/anaconda3/bin/conda run -n wty_LTL python .maintenance/paper_build.py
cf run -- /home/dell/anaconda3/bin/conda run -n wty_LTL python .maintenance/paper_build_compat.py
cf run -- /home/dell/anaconda3/bin/conda run -n wty_LTL python .maintenance/paper_integrate.py
```

上列为本轮本机维护脚本，保存在 Git 忽略的 `.maintenance/`，不是承诺随仓库分发的公共工具。持久化审阅依据包含 `long-short.diff`、保护哈希、整合清单和 `validation.json`。最终结构检查由单独维护脚本完成，见机器报告。

## 构建结果必须区分原样与兼容副本

| 场景 | 长版 | 短版 |
|---|---|---|
| 原样副本首轮 pdflatex | exit 0 | exit 0 |
| 原样副本 BibTeX | exit 0 | exit 0 |
| 原样副本后续 pdflatex | exit 1，natbib 模式冲突 | exit 1，natbib 模式冲突 |
| numbers 兼容副本完整 4 步 | 全部 exit 0 | 全部 exit 0 |
| 兼容副本最终 PDF 页数 | 13 | 9 |

4 步为 `pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex`、`bibtex manuscript`、再两次同样的 pdflatex。原样后续错误为 `Package natbib Error: Bibliography not compatible with author-year citations.`。兼容检查唯一源码调整为副本中的 `\usepackage{natbib}` → `\usepackage[numbers]{natbib}`。终稿原件没有被这样修改。

兼容副本最终仍有 `h` 浮动体自动改成 `ht` 的排版警告；本轮不是出版校样审查，没有逐像素确认每页浮动体位置。检查了 pdftotext 可提取文本、图文与表格的源码引用，未替代人工终稿校样。

两张 `zoneenv_*.png.png` 本机可由 graphicx 解析，原样首轮没有因此缺图。不把历史 `paper/` 缺图结论套用到这两套新资源。

## 原稿、代码与结果保护

- 两个终稿文件夹合计 24 文件，先保存 SHA-256，再于整合结束核对完整路径集合及内容；基准为 [protected-sources.sha256](protected-sources.sha256)。
- 三个旧稿文件迁移前后 SHA-256 相同，没有因归档改写其资源路径；旧稿隔离编译方法见档案 README。
- `src/`、`results/`、`results_infinite/`、`eval_datasets/` 的文件哈希在整合前后核对；没有算法、训练集或结果变更。
- 用户已有 AGENTS.md 修改和 `.vscode/` 内容保持原状；本轮不提交、推送。

## 恢复与持久记录

整合前 `paper/` 和被更新导航的备份在本机维护区 `.maintenance/overleaf-review/before-paper-integration.tar.gz`（Git 忽略）。恢复时应先检查并选择性提取，避免覆盖后续用户修改。旧稿本身已入档，持久迁移关系见 [integration-manifest.json](integration-manifest.json)，不会只靠维护区找回论文内容。

本轮不运行 RL 训练或性能重现实验，不声称仓库代码已与终稿完全对齐。引用条目的真实来源、原始实验日志、完整满足概率论证及论文内部待核对问题见另外两份审阅文档。
